import React from 'react';
import { AdminSidebar } from '../../components/admin/AdminSidebar';
import { DashboardCard } from '../../components/admin/DashboardCard';
import { OrdersList } from '../../components/admin/OrdersList';
import { Package, ShoppingBag, TrendingUp } from 'lucide-react';
export function AdminDashboard() {
  return <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:ml-64 p-8">
        <header className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">
            Dashboard Overview
          </h1>
          <p className="text-gray-500">Welcome back, Admin</p>
        </header>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <DashboardCard title="Total Products" value="8" icon={Package} color="red" />
          <DashboardCard title="Total Orders" value="24" icon={ShoppingBag} color="orange" />
          <DashboardCard title="Today's Orders" value="5" icon={TrendingUp} color="amber" />
        </div>

        {/* Recent Orders Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-gray-900">
                Recent WhatsApp Orders
              </h2>
              <button className="text-sm text-red-600 font-medium hover:text-red-700">
                View All
              </button>
            </div>
            <OrdersList />
          </div>

          <div>
            <div className="bg-gradient-to-br from-red-700 to-red-900 rounded-xl p-6 text-white shadow-lg">
              <h3 className="font-bold text-lg mb-2">Quick Actions</h3>
              <p className="text-red-100 text-sm mb-6">
                Manage your store efficiently
              </p>

              <div className="space-y-3">
                <button className="w-full py-2 px-4 bg-white/10 hover:bg-white/20 rounded-lg text-left text-sm font-medium transition-colors">
                  + Add New Product
                </button>
                <button className="w-full py-2 px-4 bg-white/10 hover:bg-white/20 rounded-lg text-left text-sm font-medium transition-colors">
                  Update Prices
                </button>
                <button className="w-full py-2 px-4 bg-white/10 hover:bg-white/20 rounded-lg text-left text-sm font-medium transition-colors">
                  Download Reports
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>;
}