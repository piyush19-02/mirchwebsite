import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { AdminSidebar } from "../../components/admin/AdminSidebar";
import { Input } from "../../components/shared/Input";
import { Button } from "../../components/shared/Button";

export function AddProduct() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const productId = params.get("id");

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [active, setActive] = useState(true);

  const isEdit = Boolean(productId);

  // 🔄 Fetch product for edit
  useEffect(() => {
    if (isEdit) {
      fetch(`/api/products/${productId}`)
        .then(res => res.json())
        .then(data => {
          setName(data.name);
          setPrice(data.price);
          setDescription(data.description);
          setActive(Boolean(data.active));
        });
    }
  }, [isEdit, productId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const payload = {
      name,
      price: Number(price),
      description,
      active,
    };

    const res = await fetch(
      isEdit ? `/api/products/${productId}` : "/api/products",
      {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    );

    if (res.ok) {
      navigate("/admin/products");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:ml-64 p-8">
        <h1 className="text-2xl font-bold mb-6">
          {isEdit ? "Edit Product" : "Add New Product"}
        </h1>

        <div className="max-w-2xl bg-white rounded-xl p-8 shadow">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <Input label="Product Name" value={name} onChange={e => setName(e.target.value)} />
            <Input label="Price" type="number" value={price} onChange={e => setPrice(e.target.value)} />
            <Input label="Description" multiline value={description} onChange={e => setDescription(e.target.value)} />

            <label className="flex items-center gap-2">
              <input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} />
              Active
            </label>

            <Button type="submit">
              {isEdit ? "Update Product" : "Add Product"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
