import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../components/shared/Button';
import { Input } from '../../components/shared/Input';
import { Lock, Mail } from 'lucide-react';
export function AdminLogin() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      navigate('/admin/dashboard');
    }, 1000);
  };
  return <div className="min-h-screen bg-amber-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg border border-amber-100 overflow-hidden">
        <div className="bg-red-700 p-8 text-center">
          <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
            <span className="text-3xl">🌶️</span>
          </div>
          <h1 className="text-2xl font-bold text-white">Admin Login</h1>
          <p className="text-red-100 mt-2">Mirchi Masala Store Management</p>
        </div>

        <div className="p-8">
          <form onSubmit={handleLogin} className="space-y-6">
            <Input label="Email Address" type="email" placeholder="admin@mirchi.com" defaultValue="admin@mirchi.com" required />

            <Input label="Password" type="password" placeholder="••••••••" defaultValue="admin123" required />

            <div className="pt-2">
              <Button type="submit" fullWidth size="lg" isLoading={isLoading}>
                Sign In to Dashboard
              </Button>
            </div>
          </form>

          <div className="mt-6 text-center text-sm text-gray-500 bg-gray-50 p-3 rounded-md border border-gray-100">
            <p>Demo Credentials:</p>
            <p className="font-mono text-xs mt-1">
              admin@mirchi.com / admin123
            </p>
          </div>
        </div>
      </div>
    </div>;
}