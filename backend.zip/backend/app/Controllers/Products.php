<?php
namespace App\Controllers;

use App\Models\ProductModel;

class Products extends BaseController
{
    public function add()
    {
        $model = new ProductModel();

        $image = $this->request->getFile('image');
        $imageName = null;

        if ($image && $image->isValid()) {
            $imageName = $image->getRandomName();
            $image->move(ROOTPATH . 'public/uploads/products', $imageName);
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'price' => $this->request->getPost('price'),
            'description' => $this->request->getPost('description'),
            'active' => $this->request->getPost('active'),
            'image' => $imageName,
        ];

        $model->insert($data);

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Product added successfully'
        ]);
    }

    public function list()
    {
        return $this->response->setJSON(
            (new ProductModel())->findAll()
        );
    }
    public function delete($id)
{
    $model = new \App\Models\ProductModel();

    $product = $model->find($id);
    if (!$product) {
        return $this->response->setStatusCode(404)->setJSON([
            'success' => false,
            'message' => 'Product not found'
        ]);
    }

    // image delete (optional but recommended)
    if (!empty($product['image'])) {
        $path = ROOTPATH . 'public/uploads/products/' . $product['image'];
        if (file_exists($path)) {
            unlink($path);
        }
    }

    $model->delete($id);

    return $this->response->setJSON([
        'success' => true,
        'message' => 'Product deleted'
    ]);
}
public function show($id)
{
    return $this->response->setJSON(
        (new ProductModel())->find($id)
    );
}

public function update($id)
{
    $data = $this->request->getJSON(true);
    (new ProductModel())->update($id, $data);
    return $this->response->setJSON(['success' => true]);
}

}
