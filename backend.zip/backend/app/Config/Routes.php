<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->post('api/products', 'Products::add');
$routes->get('api/products', 'Products::list');
$routes->delete('api/products/(:num)', 'Products::delete/$1');
$routes->get('api/products/(:num)', 'Products::show/$1');
$routes->put('api/products/(:num)', 'Products::update/$1');
